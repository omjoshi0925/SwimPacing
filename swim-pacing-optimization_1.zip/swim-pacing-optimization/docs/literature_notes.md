# Literature notes

Task 3, **partially complete**. 10 verified sources against a target of 15-30.

Files: `literature/references.bib`, `literature/literature_review.csv`.

---

## Status and what is missing

The search covered **swimming hydrodynamics and energetics thoroughly** and was
cut off by a tool session limit before covering the rest. What is done and what
is not:

| Topic | Status |
|---|---|
| Active drag, drag coefficient, frontal area | **done**, 5 sources |
| Propelling and mechanical efficiency | **done**, 4 sources |
| Energy cost of swimming vs velocity | **done**, 2 sources |
| Aerobic/anaerobic contribution in swimming | **not started** |
| VO2 kinetics in swimming | **not started** |
| Critical swimming speed | **not started** |
| Observed 200 free pacing | **not started** |
| Start and turn time contributions | **not started** |
| Mathematical models of athletic performance | **not started** |
| Optimal pacing in running and cycling | **not started** |
| Optimal control in endurance sport | **not started** |

The consequence is visible throughout `docs/parameters.md`: the hydrodynamic
block has real citations and the physiological block does not. `R`, `E0`, `tau`
and the start credit are all marked **PROVENANCE GAP**.

**Highest-value searches remaining**, in order:

1. **Dive start credit.** 15 m start times versus race-pace time over 15 m. This
   is the weakest number in the model and it sits on the main comparison.
2. **Anaerobic contribution to the 200 freestyle.** The model *outputs* an
   implied share of 28.7%; a published band would turn that into a real
   validation check.
3. **Observed 200 free split distributions**, elite versus sub-elite. Directly
   comparable with the M0-M4 predictions.
4. **VO2 kinetics in swimming**, for `tau`.
5. **Keller (1974) and the optimal-control-in-running line**, for positioning
   this project against prior work.

---

## Verification policy

Every entry in the `.bib` was confirmed to exist through a search result or a
fetched page. **Nothing was reconstructed from memory.** Each entry records how
far verification got:

- **full text read** (3 sources): the numbers are quoted from the paper itself.
- **abstract only** (4 sources): numbers come from the abstract. Check against
  the PDF before they appear in the paper.
- **metadata only** (3 sources): existence and bibliographic details confirmed,
  publisher page blocked by CAPTCHA or robots.txt. **No numbers extracted.**

Notably, the three sources most often cited in this area (Kolmogorov &
Duplishcheva 1992, Toussaint et al. 1988, Havriluk 2007) are precisely the three
that could only be confirmed at metadata level. Values usually attributed to
Toussaint 1988 are quoted here through Toussaint's own 2002 proceedings paper
instead, and labelled as such.

**A caution worth recording.** An initial search targeted a researcher named
"Zamparini", who does not exist in this literature. The real and prolific author
is **Paola Zamparo**. Two of the load-bearing sources here are hers. Half-
remembered author names are exactly how fabricated citations enter a
bibliography, and the correct response is to search, find nothing, and say so.

---

## What the literature changed in the model

Three findings, in descending order of consequence.

### 1. Two drag parameters were outside every measured value

The model used `C_D` = 0.70 and `A` = 0.090 m². Measured values:

| | model (old) | measured | source |
|---|---|---|---|
| `C_D` | 0.70 | 0.30 ± 0.09 (elite males, active); range 0.23-0.61 | Zamparo 2009, Kolmogorov 2021 |
| `A` | 0.090 m² | 0.23-0.24 m² active; 0.13-0.21 m² passive | Zamparo 2009 |

Both were wrong, in opposite directions, so their **product** landed near the
measured lumped coefficient while each factor sat outside the evidence. That is
a specific and instructive failure mode: a lumped parameter agreeing with the
literature does not validate its components, and a reviewer checking components
would find it immediately.

Corrected to `C_D` = 0.30 and `A` = 0.230, giving `K_d` = 34.4, which sits
inside the independently measured band (38 kg/m in Cortesi 2024; 22-30 in
Toussaint 2002). The decomposition is now defensible as well as the product.

A related trap: **passive frontal area is smaller than active area** and is the
wrong quantity for a swimming model. Using a passive figure would understate
drag by roughly half.

### 2. Gross mechanical efficiency is not a settled number

| Source | Reported efficiency | Population |
|---|---|---|
| Zamparo et al. 2005 | 0.20 ± 0.03 (overall) | swimmers, 1.0-1.4 m/s |
| Kolmogorov et al. 2021 | 0.049-0.068 (mechanical) | 8 world top-10 swimmers |

A factor of 3-4, between two legitimate peer-reviewed sources. The gap is
**definitional**, not experimental: labs differ on what counts as useful
mechanical power and what metabolic baseline is subtracted.

**Consequence: `k` is not identifiable from the literature.** Every absolute
energy figure this model produces is model-internal and cannot be compared with
published energy costs without stating the efficiency convention. This is now
flagged in `parameters.py`, `docs/parameters.md` and the README.

Propelling efficiency has the same problem in milder form: 0.40 (Cortesi 2024),
0.61 (Toussaint & Beek 1992), 0.65-0.71 (Kolmogorov 2021). A factor of 1.8.

### 3. The drag exponent may not be exactly 2

Berger et al. (1999), reported in Toussaint 2002, measured `F_d = 16.4·v^2.22`
rather than a clean quadratic. That implies `p` = 3.22 rather than 3.

This does **not** threaten any conclusion, because the central even-pacing
result holds for every `p` > 1 and the optimal shape depends on `p` only weakly.
It does mean the p-sweep in the sensitivity analysis is exercising a real
uncertainty rather than a hypothetical one.

---

## Model-relevant numbers, collected

Everything numeric that was verified, with its access level. Anything marked
[abstract] or [metadata] needs PDF confirmation before publication.

| Quantity | Value | Source | Access |
|---|---|---|---|
| Lumped drag `K` | 22-30 (top swimmers) | Toussaint 2002 | full text |
| Active drag `k_a` | 38 kg/m | Cortesi 2024 | full text |
| Passive drag `k_p` | 25 kg/m | Cortesi 2024 | full text |
| Drag exponent | 2.22 | Berger 1999 via Toussaint 2002 | full text |
| `C_D` active | 0.30 ± 0.09 | Zamparo 2009 | abstract |
| `C_D` range | 0.33-0.61 | Kolmogorov 2021 | full text |
| Frontal area active | 0.23-0.24 m² | Zamparo 2009 | abstract |
| Frontal area passive | 0.13-0.21 m² | Zamparo 2009 | abstract |
| `eta_p` | 0.61 elite / 0.44 triathlete | Toussaint & Beek 1992 | abstract |
| `eta_p` | ≈0.40 | Cortesi 2024 | full text |
| `eta_p` | 0.65-0.71 | Kolmogorov 2021 | full text |
| `eta_g` | 0.20 ± 0.03 | Zamparo 2005 | abstract |
| `eta_g` | 0.049-0.068 | Kolmogorov 2021 | full text |
| Energy cost | 600-800 J/m at 1.0-1.4 m/s | Zamparo 2005 | abstract |
| Energy cost | 0.70 kJ/m at 1.0 → 1.23 kJ/m at 1.5 m/s | Capelli 1998 | abstract, **flagged** |
| Metabolic power | 3346-3560 W (elite males, 100 m) | Kolmogorov 2021 | full text |

**An unresolved check.** The model's free-swimming cost at race pace is about
960 J/m. Capelli 1998 reports 1230 J/m at 1.5 m/s and rising exponentially,
which extrapolates well above 960 at 1.83 m/s. The model therefore looks
**cheap** relative to the free-swimming literature. That is consistent with what
`phi` is for (SCY racing includes turns and underwaters that are cheaper per
metre), but the sign and rough size should be checked properly once the Capelli
figures are confirmed against the PDF. If the gap turns out to be much larger
than turns can explain, the cost function is wrong somewhere.
