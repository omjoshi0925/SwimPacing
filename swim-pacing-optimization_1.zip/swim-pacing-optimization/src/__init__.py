"""Swim pacing optimization package."""
